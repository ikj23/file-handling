import time
from pathlib import Path
from shutil import move
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import logging

WATCHED_FOLDER = Path.home() / "Desktop"
TARGET_DIRS = {
    "PDFs": [".pdf"],
    "Images": [".jpg", ".jpeg", ".png", ".gif"],
    "Videos": [".mp4", ".mkv", ".avi"],
    "Word": [".docx",".pptx"],
    "Data": [".csv"]
}

# DEFAULT_DIR = "Others"
LOG_FILE = WATCHED_FOLDER / "file_organizer_log.txt"

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def ensure_folders_exist():
    for folder in TARGET_DIRS.keys():
        (WATCHED_FOLDER / folder).mkdir(exist_ok=True)


def move_file(file_path: Path):
    extension = file_path.suffix.lower()
    for folder, extensions in TARGET_DIRS.items():
        if extension in extensions:
            dest_folder = WATCHED_FOLDER / folder
            dest_path = dest_folder / file_path.name
            move(str(file_path), str(dest_path))
            logging.info(f"Moved '{file_path.name}' to '{dest_folder.name}'")
            return  # Done, no need to keep checking
    # If file doesn't match, leave it on Desktop
    logging.info(f"Left '{file_path.name}' on Desktop (no matching rule)")


def initial_sort():
    for item in WATCHED_FOLDER.iterdir():
        if item.is_file() and item.name != LOG_FILE.name:
            move_file(item)


class FileOrganizerHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory:
            move_file(Path(event.src_path))

if __name__ == "__main__":
    ensure_folders_exist()
    initial_sort()

    observer = Observer()
    observer.schedule(FileOrganizerHandler(), str(WATCHED_FOLDER), recursive=False)
    observer.start()

    try:
        print(f"Watching {WATCHED_FOLDER}... Press Ctrl+C to stop.")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        print("Stopped watching.")
    observer.join()
